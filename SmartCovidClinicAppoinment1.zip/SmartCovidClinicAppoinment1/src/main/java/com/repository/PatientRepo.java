package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.entity.Patient;

public interface PatientRepo extends JpaRepository<Patient,Integer>{
	Patient findBypid(int pid);	
	 
 	@Query("Select p from Patient p  where p.id=?1  order by p.pid")
	List<Patient> findByPidSorted(int pid);

	



}
