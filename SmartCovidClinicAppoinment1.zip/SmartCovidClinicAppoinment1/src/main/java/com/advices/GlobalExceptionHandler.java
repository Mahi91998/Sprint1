package com.advices;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

//import org.hibernate.resource.beans.internal.BeansMessageLogger_.logger;
//import org.hibernate.bytecode.enhance.spi.interceptor.BytecodeInterceptorLogging_.logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<?> resourceNotFoundException(ResourceNotFoundException ex, WebRequest request) {
         ErrorDetails errorDetails = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), request.getDescription(false));
         return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
    }

	
	  @ExceptionHandler(Exception.class) 
	  public ResponseEntity<?> globleExcpetionHandler(Exception ex, WebRequest request) { ErrorDetails
	  errorDetails = new ErrorDetails(LocalDateTime.now(), "Syetem exception",request.getDescription(false)); 
	//  Throwable e;
	  Logger logger= Logger.getLogger("AdminController.class");
	  //Logger logger2 = new Logger(null);
	   logger.log(Level.INFO, "My first Log Message");
	   logger.info(ex.getMessage());// --> Good
	  
	//  logger.info(ex.getMessage()) ; //--> Bad becasue it will not log statcktrace & developers need starckteace to  debug'
	  return new ResponseEntity<>(errorDetails,HttpStatus.INTERNAL_SERVER_ERROR); }
	 
}
